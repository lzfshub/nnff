# 1. 前言
用于快速开发神经网络文件框架，目前只适用于Windows系统
# 2. 安装
命令行执行`pip install nnff`
# 3. 使用
```bash
nnff -h # 查看帮助信息
nnff init # 初始化神经网络文件框架
```

